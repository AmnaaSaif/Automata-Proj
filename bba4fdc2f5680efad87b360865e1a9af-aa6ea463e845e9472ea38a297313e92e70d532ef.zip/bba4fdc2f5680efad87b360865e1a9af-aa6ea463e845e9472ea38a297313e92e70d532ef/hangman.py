import tkinter as tk
from tkinter import messagebox
import random

movies = [
    {
        "name": "Avengers: Endgame",
        "words": ["I am Iron Man", "Avengers assemble", "Whatever it takes", "On your left", "Infinity stone"]
    },
    {
        "name": "Batman v Superman",
        "words": ["Do you bleed?", "Save Martha", "Gotham city", "I am Batman", "Men are brave"]
    },
    {
        "name": "Fast and Furious",
        "words": ["Family first", "Ride or die", "One last ride", "Hobbs and Shaw", "Dominic Toretto"]
    },
    {
        "name": "Interstellar",
        "words": ["Black hole", "Time dilation", "Cooper Station", "Plan B", "NASA secret"]
    },
    {
        "name": "John Wick",
        "words": ["Continental Hotel", "Baba Yaga", "I am back", "No more rules", "He did not shoot"]
    }
]

# Globals
selected_movie = ""
selected_word = ""
display_word = []
wrong_guesses = []
max_wrong = 6
buttons = []  # Letter buttons
endgame_buttons_frame = None  # Frame for play again/exit buttons

root = tk.Tk()
root.title("Movie Hangman")
root.geometry("800x600")
root.configure(bg="#2c3e50")

main_frame = tk.Frame(root, bg="#2c3e50")
main_frame.pack(fill="both", expand=True)

def clear_screen():
    for widget in main_frame.winfo_children():
        widget.destroy()

def show_start_screen():
    clear_screen()
    tk.Label(main_frame, text="🎮 Movie Hangman", font=("Segoe UI", 40, "bold"),
             fg="#f1c40f", bg="#2c3e50").pack(pady=(100, 20))
    tk.Label(main_frame, text="Guess iconic quotes from your favorite movies",
             font=("Segoe UI", 20), fg="#bdc3c7", bg="#2c3e50").pack(pady=(0, 50))
    start_btn = tk.Button(main_frame, text="Start Game", font=("Segoe UI", 20), bg="#1abc9c", fg="white",
                          activebackground="#16a085", activeforeground="white", padx=20, pady=10,
                          command=show_movie_selection)
    start_btn.pack()

def show_movie_selection():
    clear_screen()
    tk.Label(main_frame, text="Select a Movie", font=("Segoe UI", 30, "bold"),
             fg="#f1c40f", bg="#2c3e50").pack(pady=40)

    for movie in movies:
        btn = tk.Button(main_frame, text=movie["name"], font=("Segoe UI", 18),
                        bg="#34495e", fg="white", activebackground="#1abc9c", activeforeground="white",
                        width=25, pady=10, borderwidth=0,
                        command=lambda m=movie: start_hangman_from_movie(m))
        btn.pack(pady=10)

def start_hangman_from_movie(movie):
    global selected_movie, selected_word, display_word, wrong_guesses, buttons, endgame_buttons_frame
    selected_movie = movie['name']
    selected_word = random.choice(movie['words']).upper()
    display_word = ['_' if c.isalpha() else c for c in selected_word]
    wrong_guesses = []
    buttons = []
    endgame_buttons_frame = None
    show_game_screen()

def guess_letter(letter):
    global display_word
    
    letter = letter.upper()
    if not letter.isalpha():
        messagebox.showwarning("Invalid input", "Please select a valid letter (A-Z).")
        return
    if letter in display_word or letter in wrong_guesses:
        messagebox.showwarning("Already guessed", f"You already guessed '{letter}'.")
        return

    if letter in selected_word:
        for i, c in enumerate(selected_word):
            if c == letter:
                display_word[i] = letter
    else:
        wrong_guesses.append(letter)
        messagebox.showwarning("Wrong guess", f"'{letter}' is not in the phrase.")
    
    update_game_screen()

def update_game_screen():
    word_label.config(text="\u00A0".join(display_word))
    wrong_label.config(text=f"Wrong guesses: {', '.join(wrong_guesses)} ({len(wrong_guesses)}/{max_wrong})")
    
    if "_" not in display_word:
        disable_letter_buttons()
        wrong_label.config(text="🎉 Congratulations! You guessed it!")
        show_endgame_buttons()
    elif len(wrong_guesses) >= max_wrong:
        word_label.config(text=selected_word)
        disable_letter_buttons()
        wrong_label.config(text="💀 Game Over! Better luck next time.")
        show_endgame_buttons()

def disable_letter_buttons():
    for b in buttons:
        b.config(state="disabled")

def show_endgame_buttons():
    global endgame_buttons_frame
    if endgame_buttons_frame is not None:
        return  # Already shown
    
    endgame_buttons_frame = tk.Frame(main_frame, bg="#2c3e50")
    endgame_buttons_frame.pack(pady=20)
    
    play_again_btn = tk.Button(endgame_buttons_frame, text="Play Again", font=("Segoe UI", 16),
                               bg="#27ae60", fg="white", padx=20, pady=8,
                               command=show_movie_selection)
    play_again_btn.pack(side="left", padx=20)
    
    exit_btn = tk.Button(endgame_buttons_frame, text="Exit", font=("Segoe UI", 16),
                         bg="#c0392b", fg="white", padx=20, pady=8,
                         command=root.destroy)
    exit_btn.pack(side="left", padx=20)

def show_game_screen():
    clear_screen()
    
    tk.Label(main_frame, text=f"🎬 {selected_movie}", font=("Segoe UI", 28, "bold"),
             fg="#f1c40f", bg="#2c3e50").pack(pady=(20, 10))
    
    global wrong_label
    wrong_label = tk.Label(main_frame, text=f"Wrong guesses: 0/6", font=("Segoe UI", 18), fg="#e74c3c", bg="#2c3e50")
    wrong_label.pack(pady=(0,10))
    
    global word_label
    word_label = tk.Label(main_frame, text="\u00A0".join(display_word), font=("Consolas", 32),
                          fg="white", bg="#2c3e50", wraplength=750)
    word_label.pack(pady=20)
    
    letters_frame = tk.Frame(main_frame, bg="#2c3e50")
    letters_frame.pack()
    
    global buttons
    buttons = []
    for i, letter in enumerate("ABCDEFGHIJKLMNOPQRSTUVWXYZ"):
        btn = tk.Button(letters_frame, text=letter, width=4, font=("Segoe UI", 14, "bold"),
                        bg="#34495e", fg="white",
                        command=lambda l=letter: guess_letter(l))
        btn.grid(row=i // 9, column=i % 9, padx=4, pady=4)
        buttons.append(btn)

show_start_screen()
root.mainloop()